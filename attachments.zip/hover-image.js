$(function(){
	// lightbox image
	$(".lightbox-image").append("<span></span>");
	
});